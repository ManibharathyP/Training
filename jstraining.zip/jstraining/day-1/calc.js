function calc(action, num1, num2) {

    function add() {
        return num1+ num2;

    }

    function sub(){
        return num1-num2;
    }

    function mul() {
        return num1*num2;
    }

    function div(){
        return num1/num2;
    }

    var result;
    switch(action) {
        case 1: result = add();
        break;
        case 2: result = sub();
        break;
        case 3: result = mul();
        break;
        case 4: result =  div();
        break;


    }

    return result;


}