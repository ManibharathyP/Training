var printNumber =  function() {
    console.log(10);
    
}

setTimeout(printNumber, 5000);
printNumber();

var i = 1;
setInterval(
    function(){
        console.log(++i)
    },2000);
