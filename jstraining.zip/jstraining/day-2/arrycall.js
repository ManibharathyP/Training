var arr1=[10,20,30,101];

function sumhelper(a,b)
{
    return a+b;
}
var ras=arr1.reduce(sumhelper);
console.log(ras);

function minhelper(m,e)
{
 if(m<e){
 return m;
}
 return e
}
var res=arr1.reduce(minhelper);
console.log(res);

function maxhelper(ma,s)
{
    if(ma>s)
    {
        return ma;
    }
    return s;
}
var res2=arr1.reduce(maxhelper);
console.log(res2);

function average(a,b)
{
    return (a+b)/2;
}
var res3=arr1.reduce(average);
console.log(res3);

var positiveprintelement= function(e)
{
    if(e<0)
    return ;
    else
console.log(e);
}
arr1.forEach(positiveprintelement);

var square=function(e)
{
    return e*e;
}
var res4=arr1.map(square);
console.log(res4);

function abovechecker(e)
{
    if(e>=100)
    {
        return true;
    }
    else{

        return false;
    }
}
var res5=arr1.some(abovechecker);
var res6=arr1.every(abovechecker);
var res7=arr1.find(abovechecker);
console.log(res5);
console.log(res6);
console.log(res7);
