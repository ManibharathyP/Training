var emp=
{
    "name":"mani"

}
var student=
{
    "name":"sundar"
}
function printupper()
    {
        console.log(this.name.toUpperCase());
    }
    function length(a,b)
    {
        console.log(this.name.length +a+b);
    }
printupper.call(emp);
printupper.call(student);
length.call(emp,10,20);
length.call(student,20,30);
length.apply(emp,[10,20]);
length.apply(student,[20,30]);

function doprint(a)
{
    console.log(a);
}
var print = doprint.bind(null,10);
print();

function printsum(x,y)
{
    console.log("the sum of 2 number is:"+(x+y));
}
var bind500600=printsum.bind(null,500,600);
var bind1020=printsum.bind(null,10,20);
bind500600();
bind1020();