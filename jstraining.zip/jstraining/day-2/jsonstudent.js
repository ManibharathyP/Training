

var student;

function computerating()
{
    x=this.getAverage();

    if(x>=90 )
    {
        return "A";
    }
    else if((x>=70) && (x<=79))
    {
        return "B";
    }
    else if((x>=60) && (x<=69))
    {
        return "C";
    }
    else if((x>=50) && (x<=59))
    {
        return "D";
    }
   else(x<=50)
    {
        return "failed";
    }

}

function computetotal()
{
    return this["exam"]["mark1"]+this["exam"]["mark2"]+this["exam"]["mark3"];
}
function computeaverage()
{
    return this.getTotal()/3;
}
student = {
    "student id": 101,
    "student name": "Mani",
    "exam":{"mark1": 70,
    "mark2": 60,
    "mark3": 90},
    "getTotal":computetotal,
    "getAverage":computeaverage,
    "getRating":computerating
    

}

console.log(student.getTotal());
console.log(student.getAverage());
console.log(student.getRating());
