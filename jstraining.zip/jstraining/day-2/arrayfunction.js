var mafinder=function(a,b)
{
    if(a>b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

var maxfinder1=(a,b)=>
{
    if(a>b)
    {
        return a;
    }
    else
    {
        return b;
    }
}
var simple=(a)=>
{
    console.log(a);
}
var dummy=()=>console.log(100);
arr1=[1,2,3,4,5];
arr1.forEach(simple);

setInterval(dummy,1000)
