

var emp1;

function computeAllowance(){
    switch(this["emp grade"]){
        case "A":return this["basic salary"]*0.25;
        case "B":return this["basic salary"]*0.15;
        case "C":return this["basic salary"]*0.10;
    }
}
function computeTax()
{
    return this["basic salary"]*0.1;
}
function computeNet()
{
    return this.getAllowance()+this["basic salary"]-this.getTax();
}
emp1 = {
    "emp id": 101,
    "emp name": "Mani",
    "emp gender": "M",
    "basic salary": 40000,
    "emp grade": "A",
    "getAllowance":computeAllowance,
    "getTax":computeTax,
    "getNet":computeNet
}

console.log(emp1.getAllowance());
console.log(emp1.getTax());
console.log(emp1.getNet());

for (E1 in emp1) {
    //console.log(E1 + ":" + emp1[E1]);
}