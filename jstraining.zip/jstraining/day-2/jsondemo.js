var circleobj;
circleobj={"radius":10,
            "midpoint-x":20,
            "midpoint y":25,
            "getArea":function(){
                return this.radius*this.radius*3.14;
            }
            };
var circleobj1={"radius":5,
            "midpoint-x":100,
            "midpoint y":200,
            "getArea":function(){
                return this.radius*this.radius*3.14;
            },
            "circumference":f1
            };
        
    function f1()
    {
        return this.radius*2*3.14;
    }
    circleobj["circumference"]=f1;


console.log(circleobj);
console.log(circleobj.getArea());
console.log(circleobj.radius);
console.log(circleobj["radius"]);
console.log(circleobj["midpoint-x"]);
console.log(circleobj["midpoint y"]);

var myprop="radius";
console.log(circleobj[myprop]);

for(v in circleobj)
{
    console.log(v+ ":" + circleobj[v]);
}

console.log(circleobj.circumference());
console.log(circleobj1.circumference());