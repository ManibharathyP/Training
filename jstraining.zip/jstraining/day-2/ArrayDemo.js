
var prices=[10,20,"hcl","chennai",true];

for(i=0;i<prices.length;i++)
{
    console.log(prices[i]);
}
//console.log(prices[0]);
//console.log(prices["0"]);


prices[5]="dog";
prices[10]=false;
prices[11]=function fq()
{
   
}
prices[12]=
{
    "radius":10,
    "getArea":function fq()
    {
        return this.radius*this.radius*3.14;
    }
}
for(i in prices)
{
    if(typeof i =="function")
    prices[i]();

    if(typeof i=="object")
    console.log(prices[i].getArea());
    
}